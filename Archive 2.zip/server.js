// Zero-dependency server for the FUT Champions widget.
// Run: node server.js   (Node 16+)
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const STATE_FILE = path.join(__dirname, 'state.json');
const MAX_GAMES = 15; // FUT Champions weekend run length; change if the mode differs in FC27

let state = { wins: 0, losses: 0, history: [] };
try { state = { ...state, ...JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) }; } catch {}

const clients = new Set();
const save = () => fs.writeFileSync(STATE_FILE, JSON.stringify(state));
const payload = () => JSON.stringify({ ...state, max: MAX_GAMES });
const broadcast = () => clients.forEach(res => res.write(`data: ${payload()}\n\n`));

const actions = {
  win: () => { state.wins++; state.history.push('W'); },
  loss: () => { state.losses++; state.history.push('L'); },
  undo: () => {
    const last = state.history.pop();
    if (last === 'W') state.wins = Math.max(0, state.wins - 1);
    if (last === 'L') state.losses = Math.max(0, state.losses - 1);
  },
  reset: () => { state = { wins: 0, losses: 0, history: [] }; },
};

const pages = { '/': 'overlay.html', '/control': 'control.html' };

http.createServer((req, res) => {
  const url = req.url.split('?')[0];

  if (url === '/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.write(`data: ${payload()}\n\n`);
    clients.add(res);
    req.on('close', () => clients.delete(res));
    return;
  }

  if (req.method === 'POST' && url.startsWith('/api/')) {
    const act = actions[url.slice(5)];
    if (!act) { res.writeHead(404); return res.end(); }
    act(); save(); broadcast();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(payload());
  }

  if (pages[url]) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, pages[url])));
  }
  if (url === '/bird.png') {
    res.writeHead(200, { 'Content-Type': 'image/png' });
    return res.end(fs.readFileSync(path.join(__dirname, 'bird.png')));
  }
  res.writeHead(404); res.end();
}).listen(PORT, () => {
  console.log(`Overlay (OBS Browser Source): http://localhost:${PORT}/`);
  console.log(`Control panel (OBS Dock/browser): http://localhost:${PORT}/control`);
});
